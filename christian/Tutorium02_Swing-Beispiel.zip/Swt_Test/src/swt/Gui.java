package swt;

import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * 
 * @author Chris
 * 
 */
public final class Gui {
	/**
	 * @param args
	 *            not used
	 */
	public static void main(String[] args) {

		changeLookAndFeel();

		demoFlow();

		actionButtons();

		try {
			File file = new File("res/papagei_nachher.png");
			BufferedImage image;
			image = ImageIO.read(file);
			demoIcon(image);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void changeLookAndFeel() {
		try {
			// Set cross-platform Java L&F (also called "Metal")
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
	}

	private static void demoIcon(Image image) {
		JFrame f = new JFrame();
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.add(new JLabel(new ImageIcon(image)));
		f.setSize(200, 200);
		f.setVisible(true);
	}

	private static void demoFlow() {
		JFrame f = new JFrame();
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setLayout(new FlowLayout());
		f.setSize(220, 325);
		for (int i = 0; i < 20; i++) {
			f.add(new JLabel("Text"));
			f.add(new JButton("Button"));
		}
		f.setVisible(true);
	}

	private static void actionButtons() {
		final JFrame f = new JFrame(); // final neccessary for inner class
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setLayout(new FlowLayout());
		f.setSize(220, 325);

		ActionListener listener = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser choice = new JFileChooser(new File("."));
				choice.showDialog(f, "OK, tu nichts");
			}
		};

		for (int i = 0; i < 20; i++) {
			JButton button = new JButton("Datei w�hlen");
			button.addActionListener(listener);
			f.add(button);
		}
		f.setVisible(true);
	}

	private Gui() {
		System.out.println("Gui created.");
	}
}
