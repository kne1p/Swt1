package autos;

public class F40 extends Ferrari {

}
