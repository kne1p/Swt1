package autos;

public class Ferrari extends Auto {

}
