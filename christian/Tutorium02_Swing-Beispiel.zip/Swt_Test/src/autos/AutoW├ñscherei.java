package autos;

public class AutoW�scherei extends FerrariW�scherei {

	// @Override
	void wasche(Auto a) {

	}
}
