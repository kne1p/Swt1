package autos;

public class FerrariW�scherei {
	void wasche(Ferrari f) {

	}

}
