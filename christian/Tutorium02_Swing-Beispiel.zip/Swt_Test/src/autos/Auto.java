package autos;

public class Auto {

}
